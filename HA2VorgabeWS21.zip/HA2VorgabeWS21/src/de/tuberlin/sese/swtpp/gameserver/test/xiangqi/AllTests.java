package de.tuberlin.sese.swtpp.gameserver.test.xiangqi;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ XiangqiGameTest.class, TryMoveIntegrationTest.class})
public class AllTests {
}
